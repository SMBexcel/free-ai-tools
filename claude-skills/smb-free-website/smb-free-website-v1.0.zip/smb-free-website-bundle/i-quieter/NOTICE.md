# NOTICE — i-quieter

This skill is a derivative work of Anthropic's `frontend-design` skill,
licensed under the Apache License, Version 2.0.

  Original work: https://github.com/anthropics/skills (frontend-design)
  Original copyright: Copyright (c) Anthropic, PBC.

This derivative is also distributed under Apache 2.0. A copy of the license
is available at: http://www.apache.org/licenses/LICENSE-2.0

## Changes made to this file vs. the upstream source

Per Apache License, Section 4(b), the following modifications have been made:

Forked from frontend-design quieter subskill; renamed with `i-` prefix; description rewritten for trigger discoverability; argument-hint added.

See the top-level `CHANGES.md` of the smb-free-website bundle for the
consolidated changelog across all derivative skills.
