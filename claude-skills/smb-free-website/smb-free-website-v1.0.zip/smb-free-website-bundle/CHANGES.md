# CHANGES — smb-free-website bundle

This bundle redistributes 13 design skills that are derivative works of
Anthropic's `frontend-design` skill (Apache License, Version 2.0).
Per Apache 2.0 §4(b), this file records the modifications made versus
the upstream source. See each skill's `NOTICE.md` for the per-skill
attribution and a copy of these notes.

  Upstream source: https://github.com/anthropics/skills (frontend-design)
  Upstream copyright: Copyright (c) Anthropic, PBC.
  Upstream license: Apache 2.0 — http://www.apache.org/licenses/LICENSE-2.0

## Naming convention

All 13 derivative skills carry an `i-` prefix to namespace them inside the
design quality chain coordinated by `smb-free-website`. The mapping below
shows the rename from upstream subskill name to bundled skill name.

| Upstream (frontend-design) | Bundled skill   |
|----------------------------|-----------------|
| frontend-design (root)     | i-impeccable    |
| adapt                      | i-adapt         |
| animate                    | i-animate       |
| bolder                     | i-bolder        |
| clarify                    | i-clarify       |
| critique                   | i-critique      |
| distill                    | i-distill       |
| harden                     | i-harden        |
| layout                     | i-layout        |
| overdrive                  | i-overdrive     |
| polish                     | i-polish        |
| quieter                    | i-quieter       |
| typeset                    | i-typeset       |

## Modifications applied to every derivative skill

The following changes were applied uniformly across all 13 derivative skills:

- **Renamed** each skill folder with the `i-` prefix (see mapping above).
- **Description rewritten** to surface trigger phrases relevant to the
  smb-free-website workflow and to encourage discoverability by Claude
  Code's skill-matching heuristic.
- **`argument-hint` frontmatter field added** to every skill where it was
  missing, so users see a hint when invoking the skill as a slash-command.
- **`license:` frontmatter field added** so each skill carries an
  explicit attribution back to the Anthropic upstream.
- **`NOTICE.md` added** to each skill folder, restating the upstream
  attribution and the per-skill modification summary required by
  Apache 2.0 §4(b).

## Per-skill modifications beyond the uniform changes

- **i-impeccable** — Restructured to expose three command modes
  (`craft`, `teach`, `extract`) via the `argument-hint`. The `teach`
  mode is the design-context capture step the rest of the chain
  depends on. Description rewritten to highlight the
  "Context Gathering Protocol" so other skills can reference it.
- **i-critique** — `allowed-tools` declares `Bash(npx impeccable *)`
  so the critique step can invoke the upstream `impeccable` CLI when
  it is present locally.

## Coordinator skill

The top-level `smb-free-website/` skill is **original work** by the
bundle author. It coordinates the 13 derivative design skills above
to scaffold an Astro site and walk a non-technical user through
GitHub + Cloudflare deployment. It is distributed under Apache 2.0
to match the rest of the bundle.

## How to update this changelog

If you fork or further modify any skill in this bundle, add a new
section here describing your changes, and update the corresponding
skill's `NOTICE.md` with the same delta. Apache 2.0 §4(b) requires
the modification notices to travel with the file.
