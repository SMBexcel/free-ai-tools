# smb-free-website bundle

**In about 20 minutes you'll have a real, distinctive small-business website live at your own free URL — no credit card, no monthly bill, no design experience needed.** This bundle adds the Claude Code skills that let Claude do the building for you, on top of Astro + GitHub + Cloudflare.

**How it works in 4 steps:**

1. Download and unzip this bundle.
2. Run `bash install.sh` (one command — instructions below).
3. Open Claude Code and type one slash command.
4. Walk through ~20 minutes of Q&A and a few clicks in the GitHub and Cloudflare dashboards.

**Works on macOS and Linux (including WSL). Windows-native is untested.**

Contains the **`smb-free-website`** skill plus the 13 design skills it depends on.

---

## What's inside

**The main skill** — `smb-free-website/`
End-to-end coordinator. Scaffolds Astro, configures Cloudflare, pushes to GitHub, captures design context, runs the design refinement chain, and walks you through deploy. Built-in helpers for Openverse stock photos and SVG favicons. Coaches non-tech users through the GitHub + Cloudflare GUI steps with explicit pause points.

**Design quality chain** — 7 skills, run in order during the design phase:
- `i-impeccable` — captures audience/tone/brand (the `teach` mode) and crafts the page (the `craft` mode). The most important step.
- `i-critique` — scores the design; auto-detects AI-slop anti-patterns
- `i-layout` — composition, spacing, hierarchy
- `i-adapt` — responsive, mobile-first, touch targets
- `i-clarify` — copy, CTAs, microcopy
- `i-polish` — micro-details, optical alignment
- `i-harden` — accessibility, edge cases, reduced-motion

**Optional extras** — 6 skills the chain reaches for when the brief calls for them:
- `i-overdrive` — push past "good" into "show-it-to-someone" (use sparingly)
- `i-typeset` — deep typography pass
- `i-animate` — motion + micro-interactions
- `i-bolder` / `i-quieter` — dial intensity up or down
- `i-distill` — strip to essence if a draft went maximalist

---

## Install

### First time using Terminal? Read this.

If you've never used the Terminal app before, do these steps in order — they take about a minute.

1. **Open the Terminal app.** Press `Cmd+Space`, type `Terminal`, press `Enter`. A small window with a blinking cursor appears. (On Linux, open whatever terminal your distro ships — GNOME Terminal, Konsole, etc.)
2. **Move into the unzipped bundle folder.** Type `cd ` (with a trailing space), then drag the unzipped `smb-free-website-bundle` folder from Finder onto the Terminal window and press `Enter`. You're now "inside" the folder.
3. **Run the installer.** Paste this and press `Enter`:

   ```bash
   bash install.sh
   ```

4. **If macOS blocks it** ("cannot be opened because it is from an unidentified developer"), open System Settings → Privacy & Security → scroll down → click **Open Anyway**, then re-run the command. Using `bash install.sh` (instead of `./install.sh`) sidesteps most of this.

Already comfortable with the command line? Just run `./install.sh` from this folder.

The installer copies every skill into `~/.claude/skills/`. It asks before overwriting anything that already exists. Pass `--force` to skip the prompts or `--dry-run` to preview what would happen.

After it runs, open Claude Code and type:

```
/smb-free-website my-coffee-shop
```

(or any project name — the skill takes it from there)

---

## Prerequisites the skill will check for

The skill's **Phase 0** runs a pre-flight check and tells you exactly what's missing with copy-paste install commands. You don't need to set any of this up beforehand — just run the skill and it'll walk you through.

**Heads up on time:** on a brand-new Mac with nothing installed, first-run setup (Homebrew + Xcode Command Line Tools + the tools below + Cloudflare/GitHub signup) takes **45–75 minutes**. Once those are in place, building each new site is **15–25 minutes**.

For reference:

> **Linux/WSL users:** substitute `sudo apt-get install …` (Debian/Ubuntu), `sudo dnf install …` (Fedora), or your distro's package manager wherever you see `brew install …`.

| Tool | Why | Install | Heads up |
|------|-----|---------|----------|
| **Homebrew** (macOS) | The "app store for developer tools" — free, safe, the standard way Mac devs install CLI tools. Skip on Linux/WSL. | `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"` | First run triggers Apple's Xcode Command Line Tools install — 5–15 min, modal popup, asks for your Mac password. |
| Node 22+ | Build Astro 6 | macOS: `brew install node@22` · Debian/Ubuntu: `sudo apt-get install nodejs` · Fedora: `sudo dnf install nodejs` | On a fresh Mac without Homebrew yet, install Homebrew first (row above). |
| GitHub CLI (`gh`) | Push code to GitHub | macOS: `brew install gh` · Debian/Ubuntu: `sudo apt-get install gh` · Fedora: `sudo dnf install gh` · then `gh auth login` | `gh auth login` opens a browser; you'll see a one-time code, paste it in the browser, click Authorize. |
| Cloudflare account | Free hosting | https://dash.cloudflare.com/sign-up (free, no credit card) | Cloudflare is a US-based internet infrastructure company — roughly 20% of the world's websites route through them, and the free tier here is the same one Discord, Shopify, and many Fortune 500 companies started on. If you ever want to leave, your site is just a folder on GitHub — you can move it anywhere. See the [Workers free plan limits](https://developers.cloudflare.com/workers/platform/limits/) (100K requests/day on free; upgrade to $5/mo if you outgrow it) and [Cloudflare's terms](https://www.cloudflare.com/terms/). |
| WebP (`cwebp`) | Image compression (optional — falls back to JPG) | macOS: `brew install webp` · Debian/Ubuntu: `sudo apt-get install webp` · Fedora: `sudo dnf install libwebp-tools` | Skip if you don't care about image size. |

---

## What the skill builds

A single-page (or multi-page if you ask) Astro site, hosted free on Cloudflare Workers, deployed by `git push`. **Every site goes through the full design quality chain** so the result is distinctive, not the generic AI-template look. The chain is the difference between this and a "ship me a starter."

Typical first-run time: **15–25 minutes** end-to-end, including the design Q&A and the design refinement passes.

---

## License & attribution

The entire bundle is licensed under **Apache License 2.0** — see [`LICENSE`](./LICENSE) at the bundle root for the full license text.

The `i-*` skills are derived from Anthropic's frontend-design skills (also Apache 2.0). Per-skill attribution lives in each skill's `NOTICE.md`, and the consolidated changelog of modifications versus upstream is in [`CHANGES.md`](./CHANGES.md). The `smb-free-website` skill is original work coordinating the chain — same license.

---

## Updating

To pull a newer version of the bundle: re-download, re-run `./install.sh --force`. The installer overwrites cleanly. Your projects (outside `~/.claude/skills/`) are untouched.

To update one skill without touching others: delete its folder from `~/.claude/skills/`, then either re-run this installer or copy the new version in by hand.

---

## Bundle contents

```
smb-free-website-bundle/
├── install.sh                  ← run this
├── README.md                   ← you are here
├── LICENSE                     ← full Apache 2.0 license text
├── smb-free-website/           ← the main skill
│   ├── SKILL.md
│   ├── bin/
│   │   ├── find-image.sh       ← Openverse stock photo helper
│   │   └── make-favicon.sh     ← brand-matched SVG favicon
│   └── references/
│       └── cloudflare-setup.md ← canonical URLs + setup steps
├── i-impeccable/   (SKILL.md + NOTICE.md)
├── i-critique/     (SKILL.md + NOTICE.md)
├── i-layout/       (SKILL.md + NOTICE.md)
├── i-adapt/        (SKILL.md + NOTICE.md)
├── i-clarify/      (SKILL.md + NOTICE.md)
├── i-polish/       (SKILL.md + NOTICE.md)
├── i-harden/       (SKILL.md + NOTICE.md)
├── i-overdrive/    (SKILL.md + NOTICE.md)
├── i-typeset/      (SKILL.md + NOTICE.md)
├── i-animate/      (SKILL.md + NOTICE.md)
├── i-bolder/       (SKILL.md + NOTICE.md)
├── i-quieter/      (SKILL.md + NOTICE.md)
└── i-distill/      (SKILL.md + NOTICE.md)
```
