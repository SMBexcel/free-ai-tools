#!/usr/bin/env bash
# install.sh — install the smb-free-website skill bundle into ~/.claude/skills/
#
# Usage:
#   ./install.sh             # interactive — prompts before overwriting existing skills
#   ./install.sh --force     # overwrite without prompting
#   ./install.sh --dry-run   # show what would happen, don't copy anything

set -euo pipefail

# Resolve script directory so install.sh works regardless of where it's run from
# Fall back to $0 when BASH_SOURCE is unset (e.g. piped via `curl ... | bash`)
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]:-$0}" )" && pwd )"
TARGET_DIR="${HOME}/.claude/skills"
FORCE=0
DRY_RUN=0

for arg in "$@"; do
  case "$arg" in
    --force)   FORCE=1 ;;
    --dry-run) DRY_RUN=1 ;;
    --help|-h)
      echo "Usage: $0 [--force | --dry-run]"
      echo "  --force     overwrite existing skills without prompting"
      echo "  --dry-run   show what would happen, don't copy anything"
      echo "  (--force and --dry-run are mutually exclusive)"
      exit 0
      ;;
    *)
      echo "Unknown option: $arg" >&2
      echo "Try: $0 --help" >&2
      exit 1
      ;;
  esac
done

if [[ $FORCE -eq 1 && $DRY_RUN -eq 1 ]]; then
  echo "Cannot combine --force and --dry-run" >&2
  exit 1
fi

# Sanity-check: bundle layout must be present relative to this script
# (catches `curl ... | bash` usage where SCRIPT_DIR resolves to cwd)
if [[ ! -d "${SCRIPT_DIR}/smb-free-website" ]]; then
  echo "Bundle not found relative to script — do not run this installer via 'curl | bash'." >&2
  echo "Download the bundle first, then run ./install.sh from inside it." >&2
  exit 1
fi

SKILLS=(
  smb-free-website
  i-impeccable
  i-critique
  i-layout
  i-adapt
  i-clarify
  i-polish
  i-harden
  i-overdrive
  i-typeset
  i-animate
  i-bolder
  i-quieter
  i-distill
)

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  smb-free-website skill bundle installer"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Target: ${TARGET_DIR}"
[[ $DRY_RUN -eq 1 ]] && echo "Mode:   DRY RUN (nothing will be copied)"
[[ $FORCE -eq 1 ]]   && echo "Mode:   FORCE (existing skills will be overwritten)"
echo ""

# Pre-flight: target dir must be creatable
if [[ ! -d "$TARGET_DIR" ]]; then
  if [[ $DRY_RUN -eq 0 ]]; then
    echo "Creating ${TARGET_DIR}…"
    mkdir -p "$TARGET_DIR"
  else
    echo "[dry-run] would create ${TARGET_DIR}"
  fi
fi

installed=0
skipped=0
errored=0

for skill in "${SKILLS[@]}"; do
  src="${SCRIPT_DIR}/${skill}"
  dest="${TARGET_DIR}/${skill}"

  if [[ ! -d "$src" ]]; then
    echo "  ✗ ${skill} (missing from bundle — skipping)"
    errored=$((errored + 1))
    continue
  fi

  if [[ -d "$dest" ]]; then
    if [[ $FORCE -eq 0 && $DRY_RUN -eq 0 ]]; then
      if [[ ! -t 0 ]]; then
        echo "" >&2
        echo "Non-interactive mode detected (stdin is not a TTY)." >&2
        echo "An existing skill (${skill}) needs an overwrite decision." >&2
        echo "Re-run with --force to overwrite, or --dry-run to preview." >&2
        exit 1
      fi
      read -r -p "  ? ${skill} already exists. Overwrite? [y/N] " reply
      if [[ ! "$reply" =~ ^[Yy]$ ]]; then
        echo "  - ${skill} (skipped by user)"
        skipped=$((skipped + 1))
        continue
      fi
    fi
    [[ $DRY_RUN -eq 0 ]] && rm -rf "$dest"
  fi

  if [[ $DRY_RUN -eq 1 ]]; then
    echo "  [dry-run] would copy ${skill} → ${dest}"
  else
    cp -R "$src" "$dest"
    echo "  ✓ ${skill}"
  fi
  installed=$((installed + 1))
done

# Make the bin scripts inside smb-free-website executable (cp -R preserves on macOS but check)
if [[ $DRY_RUN -eq 0 && -d "${TARGET_DIR}/smb-free-website/bin" ]]; then
  chmod +x "${TARGET_DIR}/smb-free-website/bin"/*.sh 2>/dev/null || true
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
[[ $DRY_RUN -eq 1 ]] && echo "  DRY RUN complete." || echo "  Install complete."
if [[ $DRY_RUN -eq 1 ]]; then
  echo "    Would install: ${installed}"
else
  echo "    Installed: ${installed}"
fi
[[ $skipped -gt 0 ]] && echo "    Skipped:   ${skipped}"
[[ $errored -gt 0 ]] && echo "    Errors:    ${errored}"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if [[ $DRY_RUN -eq 0 && $installed -gt 0 ]]; then
  echo "Next steps:"
  echo ""
  echo "  1. Open Claude Code (the terminal version of Claude that can read/write"
  echo "     files on your computer — different from the chat app at claude.ai)."
  echo ""
  echo "     Don't have Claude Code yet? In Terminal, run:"
  echo "         npm install -g @anthropic-ai/claude-code"
  echo "     Then launch it from any folder by typing:"
  echo "         claude"
  echo ""
  echo "     Tip: 'cd' into an empty folder first (e.g. mkdir my-coffee-shop &&"
  echo "     cd my-coffee-shop) so the skill scaffolds your site there."
  echo ""
  echo "  2. Inside Claude Code, at the prompt (NOT in Terminal), type:"
  echo "         /smb-free-website my-coffee-shop"
  echo "     (or any project name — the skill takes it from there)"
  echo ""
  echo "     You'll know it worked when Claude responds with the Phase 0"
  echo "     pre-flight checklist."
  echo ""
  echo "First-run prerequisites (the skill's Phase 0 will guide you):"
  echo "  Don't have Homebrew yet? Install it from https://brew.sh first."
  echo "  • Node 22+      brew install node@22"
  echo "  • GitHub CLI    brew install gh"
  echo "  • Cloudflare    https://dash.cloudflare.com/sign-up  (free, no card)"
  echo "  • WebP (opt.)   brew install webp"
  echo ""
fi

# Surface partial-install failures as a nonzero exit code so CI / piped callers
# don't mistake a wall of ✓ + a single ✗ for success.
[[ $errored -gt 0 ]] && exit 2
exit 0
